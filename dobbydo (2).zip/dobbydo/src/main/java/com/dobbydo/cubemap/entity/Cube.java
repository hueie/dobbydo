package com.dobbydo.cubemap.entity;

public class Cube {

}
