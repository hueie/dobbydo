package com.dobbydo.interestword.entity;

public class InterestwordVO {

}
