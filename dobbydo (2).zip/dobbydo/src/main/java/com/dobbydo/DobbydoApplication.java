package com.dobbydo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DobbydoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DobbydoApplication.class, args);
	}
	
	
}
