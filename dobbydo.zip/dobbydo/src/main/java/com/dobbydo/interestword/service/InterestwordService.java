package com.dobbydo.interestword.service;

public interface InterestwordService {

}
